﻿Imports System.Data.OleDb

Public Class frmViewMeassage

    Dim con As New OleDbConnection

    Dim ds As New DataSet
    Dim da As New OleDbDataAdapter
    Dim messageOLEDB As String
    Dim conString As String
    Dim inc As Integer

    Private Sub FrmViewMeassage_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        conString = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source ='Contact_DB.accdb'"
        con.ConnectionString = conString
        Dim Message_ID As String
        Message_ID = Me.Tag.ToString

        messageOLEDB = "select * from Message_TB where M_ID=?"
        Dim cmdMessage As New OleDbCommand(messageOLEDB, con)
        cmdMessage.CommandType = CommandType.Text
        cmdMessage.Parameters.AddWithValue("M_ID", Message_ID)
        con.Open()
        cmdMessage.ExecuteNonQuery()
        da.SelectCommand = cmdMessage
        da.Fill(ds, "selectedMessage")
        con.Close()
        displayMessage()
    End Sub




    Private Sub displayMessage()
        txtSender.Text = ds.Tables("selectedMessage").Rows(inc).Item(0)
        txtMID.Text = ds.Tables("selectedMessage").Rows(inc).Item(1)
        txtSentDate.Text = ds.Tables("selectedMessage").Rows(inc).Item(2)
        txtContent.Text = ds.Tables("selectedMessage").Rows(inc).Item(3)
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub
End Class