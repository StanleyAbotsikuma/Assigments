﻿Imports System.Data.OleDb

Public Class Form1
    Dim con As New OleDb.OleDbConnection
    Dim da As  OleDbDataAdapter
    Dim ds As New DataSet
    Dim conString As String
    Dim sql As String
    Dim maxRows As Integer
    Dim dsNewRow As DataRow
    Dim inc As Integer
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            conString = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source ='Contact_DB.accdb'"
            con = New OleDbConnection(conString)
            con.Open()
            sql = "select * from Person_TB"
            da = New OleDbDataAdapter(sql, con)
            da.Fill(ds, "AddressBook")


        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try

        NavigateRecord()
        DisableControl()
        btnCancel.Enabled = False
        btnCommit.Enabled = False
        btnSave.Enabled = False
    End Sub

    Private Sub NavigateRecord()
        txtID.Text = ds.Tables("AddressBook").Rows(inc).Item(0)
        txtFname.Text = ds.Tables("AddressBook").Rows(inc).Item(1)
        txtLname.Text = ds.Tables("AddressBook").Rows(inc).Item(2)
        cmbGender.Text = ds.Tables("AddressBook").Rows(inc).Item(3)
        dtpDateOfBirth.Value = ds.Tables("AddressBook").Rows(inc).Item(4)
        txteMail.Text = ds.Tables("AddressBook").Rows(inc).Item(5)
        txtPhone.Text = ds.Tables("AddressBook").Rows(inc).Item(6)
        txtAddress.Text = ds.Tables("AddressBook").Rows(inc).Item(7)
        txtDetails.Text = ds.Tables("AddressBook").Rows(inc).Item(8)
        maxRows = ds.Tables("AddressBook").Rows.Count


    End Sub

    Private Sub DisableControl()

        txtFname.ReadOnly = True
        txtLname.ReadOnly = True
        cmbGender.Enabled = False
        dtpDateOfBirth.Enabled = False
        txteMail.ReadOnly = True
        txtAddress.ReadOnly = True
        txtDetails.ReadOnly = True
        txtPhone.ReadOnly = True
    End Sub
    Private Sub EnableControl()
        txtFname.ReadOnly = False
        txtLname.ReadOnly = False
        cmbGender.Enabled = True
        dtpDateOfBirth.Enabled = True
        txteMail.ReadOnly = False
        txtAddress.ReadOnly = False
        txtDetails.ReadOnly = False
        txtPhone.ReadOnly = False
    End Sub
    Private Sub ClearRecord()
        txtID.Text = ""
        txtFname.Text = ""
        txtLname.Text = ""
        cmbGender.Text = "Female"
        dtpDateOfBirth.Value = Today()
        txteMail.Text = ""
        txtAddress.Text = ""
        txtDetails.Text = ""
        txtPhone.Text = ""
    End Sub

    Private Sub BtnFirst_Click(sender As Object, e As EventArgs) Handles btnFirst.Click
        If inc <> 0 Then
            inc = 0
            NavigateRecord()
        Else
            MessageBox.Show("This is the end of Records")
        End If
    End Sub

    Private Sub BtnPrev_Click(sender As Object, e As EventArgs) Handles btnPrev.Click
        If inc <> 0 Then
            inc = inc - 1
            NavigateRecord()
        Else
            MessageBox.Show("This is the Last Records")
        End If
    End Sub

    Private Sub BtnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        If inc <> maxRows - 1 Then
            inc = inc + 1
            NavigateRecord()
        Else
            MessageBox.Show("This is the Last Records")
        End If
    End Sub

    Private Sub BtnLast_Click(sender As Object, e As EventArgs) Handles btnLast.Click
        If inc <> maxRows - 1 Then
            inc = maxRows - 1
            NavigateRecord()
        Else
            MessageBox.Show("This is the Last Records")
        End If
    End Sub



    Private Sub AddRecord()
        dsNewRow.Item("FirstName") = txtFname.Text
        dsNewRow.Item("LastName") = txtLname.Text
        dsNewRow.Item("Gender") = cmbGender.Text
        dsNewRow.Item("DateOfBirth") = dtpDateOfBirth.Value
        dsNewRow.Item("eMail") = txteMail.Text
        dsNewRow.Item("PhoneNumber") = txtPhone.Text
        dsNewRow.Item("Address") = txtAddress.Text
        dsNewRow.Item("Details") = txtDetails.Text

    End Sub

    Private Sub BtnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        btnCommit.Enabled = True
        btnCancel.Enabled = True
        btnDelete.Enabled = False
        btnUpdate.Enabled = False
        btnAdd.Enabled = False
        ClearRecord()
        EnableControl()
        MessageBox.Show("Please fill in the information and select Commit to Save.")
    End Sub

    Private Sub BtnCommit_Click(sender As Object, e As EventArgs) Handles btnCommit.Click
        Dim cb As New OleDbCommandBuilder(da)
        Try
            dsNewRow = ds.Tables("AddressBook").NewRow()
            AddRecord()
            ds.Tables("AddressBook").Rows.Add(dsNewRow)
            da.Update(ds, "AddressBook")
            MessageBox.Show("New Record Save Succesfully..")
            btnCommit.Enabled = False
            btnCancel.Enabled = False
            btnDelete.Enabled = True
            btnUpdate.Enabled = True
            btnAdd.Enabled = True
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try
        Form1_Load(Me, New System.EventArgs)
        NavigateRecord()
    End Sub
End Class
