﻿Imports System.Data.OleDb

Public Class Form1
    Dim con As New OleDb.OleDbConnection
    Dim da As  OleDbDataAdapter
    Dim ds As New DataSet
    Dim conString As String
    Dim sql As String
    Dim maxRows As Integer
    Dim dsNewRow As DataRow
    Dim inc As Integer
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            conString = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source ='Contact_DB.accdb'"
            con = New OleDbConnection(conString)
            con.Open()
            sql = "select * from Person_TB"
            da = New OleDbDataAdapter(sql, con)
            da.Fill(ds, "AddressBook")


        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try

        NavigateRecord()
        DisableControl()
        btnCancel.Enabled = False
        btnCommit.Enabled = False
        btnSave.Enabled = False
    End Sub

    Private Sub NavigateRecord()
        txtID.Text = ds.Tables("AddressBook").Rows(inc).Item(0)
        txtFname.Text = ds.Tables("AddressBook").Rows(inc).Item(1)
        txtLname.Text = ds.Tables("AddressBook").Rows(inc).Item(2)
        cmbGender.Text = ds.Tables("AddressBook").Rows(inc).Item(3)
        dtpDateOfBirth.Value = ds.Tables("AddressBook").Rows(inc).Item(4)
        txteMail.Text = ds.Tables("AddressBook").Rows(inc).Item(5)
        txtPhone.Text = ds.Tables("AddressBook").Rows(inc).Item(6)
        txtAddress.Text = ds.Tables("AddressBook").Rows(inc).Item(7)
        txtDetails.Text = ds.Tables("AddressBook").Rows(inc).Item(8)
        maxRows = ds.Tables("AddressBook").Rows.Count


    End Sub

    Private Sub DisableControl()

        txtFname.ReadOnly = True
        txtLname.ReadOnly = True
        cmbGender.Enabled = False
        dtpDateOfBirth.Enabled = False
        txteMail.ReadOnly = True
        txtAddress.ReadOnly = True
        txtDetails.ReadOnly = True
        txtPhone.ReadOnly = True
    End Sub
    Private Sub EnableControl()
        txtFname.ReadOnly = False
        txtLname.ReadOnly = False
        cmbGender.Enabled = True
        dtpDateOfBirth.Enabled = True
        txteMail.ReadOnly = False
        txtAddress.ReadOnly = False
        txtDetails.ReadOnly = False
        txtPhone.ReadOnly = False
    End Sub
    Private Sub ClearRecord()
        txtID.Text = ""
        txtFname.Text = ""
        txtLname.Text = ""
        cmbGender.Text = "Female"
        dtpDateOfBirth.Value = Today()
        txteMail.Text = ""
        txtAddress.Text = ""
        txtDetails.Text = ""
        txtPhone.Text = ""
    End Sub

    Private Sub BtnFirst_Click(sender As Object, e As EventArgs) Handles btnFirst.Click
        If inc <> 0 Then
            inc = 0
            NavigateRecord()
        Else
            MessageBox.Show("This is the end of Records")
        End If
    End Sub

    Private Sub BtnPrev_Click(sender As Object, e As EventArgs) Handles btnPrev.Click
        If inc <> 0 Then
            inc = inc - 1
            NavigateRecord()
        Else
            MessageBox.Show("This is the Last Records")
        End If
    End Sub

    Private Sub BtnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        If inc <> maxRows - 1 Then
            inc = inc + 1
            NavigateRecord()
        Else
            MessageBox.Show("This is the Last Records")
        End If
    End Sub

    Private Sub BtnLast_Click(sender As Object, e As EventArgs) Handles btnLast.Click
        If inc <> maxRows - 1 Then
            inc = maxRows - 1
            NavigateRecord()
        Else
            MessageBox.Show("This is the Last Records")
        End If
    End Sub



    Private Sub AddRecord()
        dsNewRow.Item("FirstName") = txtFname.Text
        dsNewRow.Item("LastName") = txtLname.Text
        dsNewRow.Item("Gender") = cmbGender.Text
        dsNewRow.Item("DateOfBirth") = dtpDateOfBirth.Value
        dsNewRow.Item("eMail") = txteMail.Text
        dsNewRow.Item("PhoneNumber") = txtPhone.Text
        dsNewRow.Item("Address") = txtAddress.Text
        dsNewRow.Item("Details") = txtDetails.Text

    End Sub

    Private Sub BtnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        btnCommit.Enabled = True
        btnCancel.Enabled = True
        btnDelete.Enabled = False
        btnUpdate.Enabled = False
        btnAdd.Enabled = False
        btnSave.Enabled = False

        ClearRecord()
        EnableControl()
        MessageBox.Show("Please fill in the information and select Commit to Save.")
    End Sub

    Private Sub BtnCommit_Click(sender As Object, e As EventArgs) Handles btnCommit.Click
        Dim cb As New OleDbCommandBuilder(da)
        Try
            dsNewRow = ds.Tables("AddressBook").NewRow()
            AddRecord()
            ds.Tables("AddressBook").Rows.Add(dsNewRow)
            da.Update(ds, "AddressBook")
            MessageBox.Show("New Record Save Succesfully..")
            btnCommit.Enabled = False
            btnCancel.Enabled = False
            btnDelete.Enabled = True
            btnUpdate.Enabled = True
            btnAdd.Enabled = True
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try
        Form1_Load(Me, New System.EventArgs)
        NavigateRecord()
    End Sub

    Private Sub BtnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        btnCommit.Enabled = False
        btnSave.Enabled = True
        btnCancel.Enabled = True
        btnDelete.Enabled = False
        btnUpdate.Enabled = False
        btnAdd.Enabled = False
        EnableControl()
        MessageBox.Show("Please make the changes and select  Save.")

    End Sub

    Private Sub BtnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Dim cb As New OleDbCommandBuilder(da)
        Try
            ds.Tables("AddressBook").Rows(inc).Item(1) = txtFname.Text
            ds.Tables("AddressBook").Rows(inc).Item(2) = txtLname.Text
            ds.Tables("AddressBook").Rows(inc).Item(3) = cmbGender.Text
            ds.Tables("AddressBook").Rows(inc).Item(4) = dtpDateOfBirth.Value
            ds.Tables("AddressBook").Rows(inc).Item(5) = txteMail.Text
            ds.Tables("AddressBook").Rows(inc).Item(6) = txtPhone.Text
            ds.Tables("AddressBook").Rows(inc).Item(7) = txtAddress.Text
            ds.Tables("AddressBook").Rows(inc).Item(8) = txtDetails.Text
            da.Update(ds, "AddressBook")
            btnCancel.Enabled = False
            btnCommit.Enabled = False
            btnSave.Enabled = False

            btnDelete.Enabled = True
            btnUpdate.Enabled = True
            btnAdd.Enabled = True
            DisableControl()
            MessageBox.Show("Update Successfully")
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try

    End Sub

    Private Sub BtnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        NavigateRecord()
        MessageBox.Show("Editting Stopped")
        btnCancel.Enabled = False
        btnCommit.Enabled = False
        btnSave.Enabled = False

        btnDelete.Enabled = True
        btnUpdate.Enabled = True
        btnAdd.Enabled = True

    End Sub

    Private Sub BtnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Try
            If MessageBox.Show("Do you really want to delete this record?", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = DialogResult.No Then
                MessageBox.Show("Operation Cancelled")
                Exit Sub
            Else
                Dim cb As New OleDbCommandBuilder(da)
                ds.Tables("AddressBook").Rows(inc).Delete()
                maxRows = maxRows - 1
                inc = 0
                da.Update(ds, "AddressBook")
                ClearRecord()
                NavigateRecord()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.ToString)

        End Try
    End Sub

    Private Sub SearchToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SearchToolStripMenuItem.Click
        Dim ID As String
        Static keepId As Integer
        Dim ISFound As Boolean = False
        inc = 0

        Try
            ID = InputBox("Please enter an ID to Search")
            If ID = "" Then
                MessageBox.Show("You must enter a value to Search")
            End If

            Do While inc < maxRows
                If ID = ds.Tables("AddressBook").Rows(inc).Item("P_ID") Then
                    keepId = inc
                    ISFound = True
                    Exit Try
                End If
                inc = inc + 1
            Loop

        Catch ex As Exception

            MessageBox.Show(ex.ToString)

        End Try

        If ISFound Then
            inc = keepId
            NavigateRecord()
        Else
            MessageBox.Show("Record not found")
        End If
    End Sub

    Private Sub EToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub OpenSQLWindowToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OpenSQLWindowToolStripMenuItem.Click
        SQLDBContactApp.Show()

    End Sub

    Private Sub MessagesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MessagesToolStripMenuItem.Click
        Dim Person_ID As String = txtID.Text
        Dim messageForm As New frmViewContactMessages
        messageForm.Tag = Person_ID
        messageForm.ShowDialog()
    End Sub

    Private Sub CallsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CallsToolStripMenuItem.Click
        Dim Person_ID As String = txtID.Text
        Dim callForm As New frmViewContactCalls
        callForm.Tag = Person_ID
        callForm.ShowDialog()
    End Sub
End Class
