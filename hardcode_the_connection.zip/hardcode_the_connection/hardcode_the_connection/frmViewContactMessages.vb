﻿Imports System.Data.OleDb


Public Class frmViewContactMessages


    Dim con As New OleDbConnection
    Dim da As New OleDbDataAdapter
    Dim ds As New DataSet
    Dim conString As String

    Dim personSQL As String
    Dim messageSQL As String
   
    Dim inc As Integer


    '  conString = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source ='Contact_DB.accdb'"
    '  con = New OleDbConnection(conString)
    '  con.Open()
    '  sql = "select * from Person_TB"
    '  da = New OleDbDataAdapter(sql, con)
    '  da.Fill(ds, "AddressBook")



    Private Sub FrmViewContactMessages_Load(sender As Object, e As EventArgs) Handles MyBase.Load



        conString = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source ='Contact_DB.accdb'"

            con.ConnectionString = conString
        '   used to store the ID of the selected contact passed from Form1
        Dim Person_ID As String
        Person_ID = Me.Tag.ToString

        'the parameterize query to fetch data on the selected contact
        Dim personOleDB As String = "select * from Person_TB where P_ID=?"
            Dim cmdPerson As New OleDbCommand(personOleDB, con)

        cmdPerson.CommandType = CommandType.Text
            cmdPerson.Parameters.AddWithValue("P_ID", Person_ID)
            con.Open()

        cmdPerson.ExecuteNonQuery()

        da.SelectCommand = cmdPerson
        da.Fill(ds, "selectedPerson")


        Dim messageSQL As String = "select * from Message_TB where Sender_ID=?"
        Dim cmdMessage As New OleDbCommand(messageSQL, con)
        cmdMessage.CommandType = CommandType.Text

        cmdMessage.Parameters.AddWithValue("Sender_ID", Person_ID)
        cmdMessage.ExecuteNonQuery()
        da.SelectCommand = cmdMessage
        da.Fill(ds, "selectedPersonMessages")
        con.Close()
        showData()




    End Sub



    'the parameterize query to fetch data on the messages sent by the selected contact

    Private Sub showData()
        txtID.Text = ds.Tables("selectedPerson").Rows(inc).Item(0)
        txtFname.Text = ds.Tables("selectedPerson").Rows(inc).Item(1)
        txtLname.Text = ds.Tables("selectedPerson").Rows(inc).Item(2)
        cmbGender.Text = ds.Tables("selectedPerson").Rows(inc).Item(3)
        dtpDateOfBirth.Value = ds.Tables("selectedPerson").Rows(inc).Item(4)
        txteMail.Text = ds.Tables("selectedPerson").Rows(inc).Item(5)
        txtPhone.Text = ds.Tables("selectedPerson").Rows(inc).Item(6)
        txtAddress.Text = ds.Tables("selectedPerson").Rows(inc).Item(7)
        txtDetails.Text = ds.Tables("selectedPerson").Rows(inc).Item(8)
        'link (bound) the Datagridview control to the selectedPersonMessages in the ds dataset
        dgvMessages.DataSource = ds.Tables("selectedPersonMessages")
        'Display the inserted (ViewMessage) column as the last column in the datagridview
        dgvMessages.Columns("ViewMessage").DisplayIndex = 4

    End Sub

    Private Sub DgvMessages_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvMessages.CellContentClick
        If e.ColumnIndex = 0 Then
            ' ViewMessage button clicked
            ' Get the ID of the selected Message
            Dim i As Integer = e.RowIndex
            Dim row As DataGridViewRow = dgvMessages.Rows(i)
            Dim cell As DataGridViewCell = row.Cells(1)
            Dim MessageID As String = cell.Value
            ' Display the ViewMeassage form
            Dim messageForm As New frmViewMeassage
            messageForm.Tag = MessageID
            messageForm.ShowDialog()
        End If
    End Sub
End Class