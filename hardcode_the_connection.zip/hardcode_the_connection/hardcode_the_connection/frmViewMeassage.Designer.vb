﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmViewMeassage
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtMID = New System.Windows.Forms.TextBox()
        Me.txtSentDate = New System.Windows.Forms.TextBox()
        Me.txtSender = New System.Windows.Forms.TextBox()
        Me.txtContent = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(64, 46)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(41, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Sender"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(40, 72)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(64, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Message ID"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(73, 99)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(30, 13)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Date"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(64, 163)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(50, 13)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "Message"
        '
        'txtMID
        '
        Me.txtMID.Location = New System.Drawing.Point(109, 66)
        Me.txtMID.Name = "txtMID"
        Me.txtMID.Size = New System.Drawing.Size(185, 20)
        Me.txtMID.TabIndex = 2
        '
        'txtSentDate
        '
        Me.txtSentDate.Location = New System.Drawing.Point(109, 96)
        Me.txtSentDate.Name = "txtSentDate"
        Me.txtSentDate.Size = New System.Drawing.Size(185, 20)
        Me.txtSentDate.TabIndex = 3
        '
        'txtSender
        '
        Me.txtSender.Location = New System.Drawing.Point(109, 40)
        Me.txtSender.Name = "txtSender"
        Me.txtSender.Size = New System.Drawing.Size(185, 20)
        Me.txtSender.TabIndex = 4
        '
        'txtContent
        '
        Me.txtContent.Location = New System.Drawing.Point(67, 189)
        Me.txtContent.Multiline = True
        Me.txtContent.Name = "txtContent"
        Me.txtContent.Size = New System.Drawing.Size(227, 191)
        Me.txtContent.TabIndex = 5
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(219, 417)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 6
        Me.Button1.Text = "Exit"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'frmViewMeassage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(340, 529)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.txtContent)
        Me.Controls.Add(Me.txtSender)
        Me.Controls.Add(Me.txtSentDate)
        Me.Controls.Add(Me.txtMID)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmViewMeassage"
        Me.Text = "frmViewMeassage"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents txtMID As TextBox
    Friend WithEvents txtSentDate As TextBox
    Friend WithEvents txtSender As TextBox
    Friend WithEvents txtContent As TextBox
    Friend WithEvents Button1 As Button
End Class
